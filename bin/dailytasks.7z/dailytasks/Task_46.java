package dailytasks;

import java.util.Scanner;

public class Task_46 {

	public static void main(String[] args) {
	 
		Scanner obj = new Scanner(System.in);
		 String str;
		 
		 System.out.println("Enter String:");
		 str=obj.nextLine();

		 System.out.println(str.replaceAll("\\s+", ""));//formula to remove spaces
		 
	    }    
		
		
	    
	  }


package dailytasks;

public class Task_45 {
	//java program printing duplicates from array
	

	
	public static void main(String[] args) {
	    
	    
	  }
}
